﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Sessia_2.Classes;

namespace Sessia_2
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MainFrame.Navigate(new Abonent());
            Manager.MainFrame = MainFrame;
            Users.ItemsSource = PMBaseEntities.GetContext().Сотрудники.ToList();

            Users.SelectedValue = "ФИО";
            Users.SelectedIndex = -1;
            Users.DisplayMemberPath = "ФИО";
        }


        private void abonents_Click(object sender, RoutedEventArgs e)
        {
            Uri uri = new Uri("Abonent.xaml", UriKind.Relative);
            this.MainFrame.Navigate(uri);
        }

        private void support_Copy2_Click(object sender, RoutedEventArgs e)
        {
            Uri uri = new Uri("Aktivs.xaml", UriKind.Relative);
            this.MainFrame.Navigate(uri);
        }
    }
}
